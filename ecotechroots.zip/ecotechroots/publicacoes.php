<?php
session_start();
include_once 'php/conexao.php';
include_once 'php/auth.php';

$user = get_logged_user($mysqli);

// Buscar publicações com nome do usuário
$sql = "SELECT p.id_publicacao, p.nm_publicacao, p.descricao, p.img_publicacao, u.nm_usuario
        FROM tb_publicacao p
        JOIN tb_usuarios u ON p.tb_usuarios_id_usuarios = u.id_usuarios
        ORDER BY p.id_publicacao DESC";
$result = $mysqli->query($sql);

$publicacoes = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $publicacoes[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Publicações - EcotechRoots</title>
  <link rel="shortcut icon" href="favicon.com/favicon.png" type="image/x-icon" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet" />
  <style>
    /* Carrossel básico */
    .carrossel {
      max-width: 600px;
      margin: 30px auto;
      position: relative;
      overflow: hidden;
      border: 1px solid #ddd;
      border-radius: 8px;
      background: #fff;
    }
    .carrossel-inner {
      white-space: nowrap;
      transition: transform 0.5s ease;
    }
    .publicacao {
      display: inline-block;
      width: 600px;
      padding: 20px;
      vertical-align: top;
      box-sizing: border-box;
    }
    .publicacao img {
      max-width: 100%;
      height: auto;
      margin-bottom: 10px;
      border-radius: 6px;
    }
    .btn-carrossel {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      background-color: rgba(0,0,0,0.3);
      border: none;
      color: white;
      font-size: 24px;
      padding: 6px 12px;
      cursor: pointer;
      border-radius: 50%;
      user-select: none;
    }
    #prev {
      left: 10px;
    }
    #next {
      right: 10px;
    }
  </style>
</head>
<body>

<!-- Header -->
<header class="d-flex align-items-center px-4 py-2">
  <a href="telainicial.php" class="d-flex align-items-center gap-2 me-auto">
    <img src="image/logo ecotech.png" alt="Logo EcotechRoots" width="80" height="80" />
  </a>

  <span class="fw-bold text-white mx-auto">EcotechRoots</span>

  <?php if ($user): ?>
    <div class="d-flex align-items-center ms-auto">
      <?php if (!empty($user['img_perfil'])): ?>
        <a href="perfil.php">
          <img src="uploads/perfis/<?php echo htmlspecialchars($user['img_perfil']); ?>" alt="Perfil" class="rounded-circle" width="40" height="40" style="object-fit: cover; margin-right:10px; cursor:pointer;" />
        </a>
      <?php else: ?>
        <a href="perfil.php">
          <img src="image/imguser.png" alt="Perfil" class="rounded-circle" width="40" height="40" style="object-fit: cover; margin-right:10px; cursor:pointer;" />
        </a>
      <?php endif; ?>

      <form action="php/logout.php" method="post" style="margin:0;">
        <button type="submit" class="btn btn-outline-light btn-sm">Sair</button>
      </form>
    </div>
  <?php else: ?>
    <a href="telalogin.php" class="fw-bold text-white text-decoration-none ms-auto">Entrar</a>
  <?php endif; ?>
</header>

<main class="container my-4">
  <h1 class="text-center mb-4">Publicações</h1>

  <?php if (empty($publicacoes)): ?>
    <p class="text-center">Nenhuma publicação encontrada.</p>
  <?php else: ?>

  <div class="carrossel">
    <button id="prev" class="btn-carrossel">&#10094;</button>
    <div class="carrossel-inner" id="carrosselInner">
      <?php foreach ($publicacoes as $pub): ?>
        <div class="publicacao">
          <h3><?= htmlspecialchars($pub['nm_publicacao']) ?></h3>
          <p><small><em>Por: <?= htmlspecialchars($pub['nm_usuario']) ?></em></small></p>
          <?php if (!empty($pub['img_publicacao']) && file_exists($pub['img_publicacao'])): ?>
            <img src="<?= htmlspecialchars($pub['img_publicacao']) ?>" alt="Imagem da publicação" />
          <?php endif; ?>
          <p><?= nl2br(htmlspecialchars($pub['descricao'])) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
    <button id="next" class="btn-carrossel">&#10095;</button>
  </div>

  <?php endif; ?>
</main>

<script>
  const carrosselInner = document.getElementById('carrosselInner');
  const totalItems = carrosselInner.children.length;
  let currentIndex = 0;

  document.getElementById('next').addEventListener('click', () => {
    if (currentIndex < totalItems - 1) {
      currentIndex++;
      updateCarousel();
    }
  });

  document.getElementById('prev').addEventListener('click', () => {
    if (currentIndex > 0) {
      currentIndex--;
      updateCarousel();
    }
  });

  function updateCarousel() {
    carrosselInner.style.transform = `translateX(-${currentIndex * 600}px)`;
  }
</script>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
