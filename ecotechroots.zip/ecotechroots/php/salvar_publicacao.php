<?php
session_start();
include_once 'conexao.php';
include_once 'auth.php';

$user = get_logged_user($mysqli);
if (!$user) {
    header('Location: ../telalogin.php');
    exit;
}

// Receber e validar dados
$nm_publicacao = trim($_POST['nm_publicacao'] ?? '');
$descricao = trim($_POST['descricao'] ?? '');
$img_path = null;

if ($nm_publicacao === '' || $descricao === '') {
    $_SESSION['msg_publicar'] = "Título e descrição são obrigatórios.";
    header('Location: ../publicar.php');
    exit;
}

// Limitar tamanho dos textos (mesmo que no formulário)
if (mb_strlen($nm_publicacao) > 45 || mb_strlen($descricao) > 150) {
    $_SESSION['msg_publicar'] = "Texto muito longo.";
    header('Location: ../publicar.php');
    exit;
}

// Processar upload de imagem, se enviada
if (isset($_FILES['img_publicacao']) && $_FILES['img_publicacao']['error'] === UPLOAD_ERR_OK) {
    $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $arquivo_tmp = $_FILES['img_publicacao']['tmp_name'];
    $nome_original = $_FILES['img_publicacao']['name'];
    $ext = strtolower(pathinfo($nome_original, PATHINFO_EXTENSION));

    if (!in_array($ext, $extensoes_permitidas)) {
        $_SESSION['msg_publicar'] = "Formato de imagem não permitido.";
        header('Location: ../publicar.php');
        exit;
    }

    $novo_nome = uniqid('pub_') . '.' . $ext;
    $pasta_destino = '../uploads/publicacoes/';

    if (!is_dir($pasta_destino)) {
        mkdir($pasta_destino, 0755, true);
    }

    $destino_completo = $pasta_destino . $novo_nome;

    if (move_uploaded_file($arquivo_tmp, $destino_completo)) {
        // Caminho salvo relativo ao arquivo publicacoes.php
        $img_path = 'uploads/publicacoes/' . $novo_nome;
    } else {
        $_SESSION['msg_publicar'] = "Erro ao salvar imagem.";
        header('Location: ../publicar.php');
        exit;
    }
}

// Inserir no banco
$stmt = $mysqli->prepare("INSERT INTO tb_publicacao (nm_publicacao, descricao, img_publicacao, tb_usuarios_id_usuarios) VALUES (?, ?, ?, ?)");
if (!$stmt) {
    $_SESSION['msg_publicar'] = "Erro no banco de dados.";
    header('Location: ../publicar.php');
    exit;
}
$stmt->bind_param("sssi", $nm_publicacao, $descricao, $img_path, $user['id_usuarios']);
if ($stmt->execute()) {
    $_SESSION['msg_publicar'] = "Publicação criada com sucesso!";
} else {
    $_SESSION['msg_publicar'] = "Erro ao salvar publicação.";
}
$stmt->close();

header('Location: ../publicar.php');
exit;
