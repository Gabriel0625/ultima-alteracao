<?php
session_start();
include_once 'php/conexao.php';
include_once 'php/auth.php';

$user = get_logged_user($mysqli);
if (!$user) {
    // Se não está logado, redireciona para login
    header('Location: telalogin.php');
    exit;
}

$msg = $_SESSION['msg_publicar'] ?? '';
unset($_SESSION['msg_publicar']);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Nova Publicação - EcotechRoots</title>
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>

<header class="d-flex align-items-center px-4 py-2">
  <a href="telainicial.php" class="d-flex align-items-center gap-2 me-auto">
    <img src="image/logo ecotech.png" alt="Logo EcotechRoots" width="80" height="80" />
  </a>

  <span class="fw-bold text-white mx-auto">EcotechRoots</span>

  <div class="d-flex align-items-center ms-auto">
    <?php if (!empty($user['img_perfil'])): ?>
      <a href="perfil.php">
        <img src="uploads/perfis/<?php echo htmlspecialchars($user['img_perfil']); ?>" alt="Perfil" class="rounded-circle" width="40" height="40" style="object-fit: cover; margin-right:10px; cursor:pointer;" />
      </a>
    <?php else: ?>
      <a href="perfil.php">
        <img src="image/imguser.png" alt="Perfil" class="rounded-circle" width="40" height="40" style="object-fit: cover; margin-right:10px; cursor:pointer;" />
      </a>
    <?php endif; ?>

    <form action="php/logout.php" method="post" style="margin:0;">
      <button type="submit" class="btn btn-outline-light btn-sm">Sair</button>
    </form>
  </div>
</header>

<main class="container my-4">
  <h1 class="mb-4">Nova Publicação</h1>

  <?php if ($msg): ?>
    <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <form action="php/salvar_publicacao.php" method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label for="nm_publicacao" class="form-label">Título da Publicação</label>
      <input type="text" class="form-control" id="nm_publicacao" name="nm_publicacao" required maxlength="45" />
    </div>

    <div class="mb-3">
      <label for="descricao" class="form-label">Descrição</label>
      <textarea class="form-control" id="descricao" name="descricao" rows="4" maxlength="150" required></textarea>
    </div>

    <div class="mb-3">
      <label for="img_publicacao" class="form-label">Imagem (opcional)</label>
      <input type="file" class="form-control" id="img_publicacao" name="img_publicacao" accept="image/*" />
    </div>

    <button type="submit" class="btn btn-success">Publicar</button>
  </form>
</main>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
